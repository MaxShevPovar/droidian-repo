#!/bin/sh
insmod --force /vendor/lib/modules/wmt_drv.ko 2>/dev/null
insmod --force /vendor/lib/modules/connfem.ko 2>/dev/null
insmod --force /vendor/lib/modules/wmt_chrdev_wifi.ko 2>/dev/null
insmod --force /vendor/lib/modules/wlan_drv_gen4m.ko 2>/dev/null
sleep 3